<?php

namespace DynamicContentForElementor;

use DynamicContentForElementor\Helper;
use DynamicContentForElementor\Dashboard;
use DynamicContentForElementor\GlobalSettings;
use DynamicContentForElementor\Widgets;
if (!\defined('ABSPATH')) {
    exit;
}
/**
 * Settings Class
 *
 * Settings page
 *
 * @since 0.0.1
 */
class Settings
{
    private $options = array();
    /**
     * Constructor
     *
     * @since 0.0.1
     *
     * @access public
     */
    public function __construct()
    {
    }
}
